const mongoose = require("mongoose")

const MongoDBConexion = ()=>{

    try {
        mongoose.connect(process.env.MONGO_CNN)
        console.log("Conexion exitosa")

    } catch (error) {
        console.log("Error de Conexion" + error)
    }

}

module.exports = {
    MongoDBConexion
}