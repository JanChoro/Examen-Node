
const User = require("../models/users.models")
const { request, response} = require('express')
const getUser =async (req = request,res=response) =>{

    const allusers = await User.find()
     res.send({
        "ok" : 200,
        allusers
     })

}

const postUser =async (req = request,res=response) =>{

    const data = req.body;
console.log(data);
    // const Usernuevo = await new User(data)

    // await Usernuevo.save()

    //  res.send({
    //     "ok" : 200,
    //     "msg":"Usuario creado"
    //  })

}

const putUser =async (req = request,res=response) =>{

    const paramts = User.params.id; 

    const {documento, nombre, apellido, telefono, usuario, clave, estado } = req.body
    
    const actualizar =await User.findByIdAndUpdate(paramts, {
        documento, nombre, apellido, telefono, usuario, clave, estado
    })
    // await actualizar.save()

     res.send({
        "ok" : 200,
        "msg":"Usuario actualizado"
     })

}


const deleteUser =async (req = request,res=response) =>{

    const id = User.params.id;
    const eliminar = await User.findByIdAndDelete(id);

     res.send({
        "ok" : 200,
        "msg" : "Usuario eliminado"
     })

}

module.exports = {
    getUser,
    postUser,
    putUser,
    deleteUser
}