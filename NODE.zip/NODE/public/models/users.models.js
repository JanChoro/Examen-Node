
const { Schema, model } = require("mongoose")

const UserModel = new Schema({

    documento: {
        type: Number,
        unique: true,
        required: true
    },

    nombre: {
        type: String,
        required: ["Nombre requerido"]
    },

    apellido: {
        type: String,
        required: ["Apellido requerido"]
    },

    telefono: {
        type: Number,
        required: ["Telefono requerido"]
    },

        
    usuario: {
        type: String,
        unique: true,
        required: ["Usuario requerido"]
    },

    clave: {
        type: String,
        required: ["Clave requerida"]
    },

    estado: {
        type: Boolean,
        default: false,
        required: ["Clave requerida"]
    }


})

module.exports = model("user" , UserModel)