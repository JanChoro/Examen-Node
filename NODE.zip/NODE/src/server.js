const express = require("express")
const { MongoDBConexion } = require("../public/db/config.db")

class Server {

    constructor() {
        this.port = (process.env.port)
        this.app = express();

        this.dbConexion()
        this.route()
        this.middleware()

    }

    dbConexion() {
        MongoDBConexion
    };

    route() {
        this.app.use("/api/user", require("../public/routes/users.routes"))
    }

    middleware() {
        this.app.use(express.static("public"))
        this.app.use(express.json())
    }

    listen() {
        this.app.listen(this.port, () => {
            console.log("Puerto http://localhost:" + this.port)
        })
    }

}

module.exports = Server